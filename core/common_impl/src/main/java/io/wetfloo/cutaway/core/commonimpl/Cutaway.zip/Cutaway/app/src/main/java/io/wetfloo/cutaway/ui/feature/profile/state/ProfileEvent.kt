package io.wetfloo.cutaway.ui.feature.profile.state

sealed interface ProfileEvent
