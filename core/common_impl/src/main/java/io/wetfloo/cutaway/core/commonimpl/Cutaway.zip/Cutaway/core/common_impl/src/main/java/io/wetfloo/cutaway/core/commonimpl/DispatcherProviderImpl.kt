package io.wetfloo.cutaway.core.commonimpl

import io.wetfloo.cutaway.core.common.DispatcherProvider
import javax.inject.Inject

class DispatcherProviderImpl @Inject constructor() : DispatcherProvider
