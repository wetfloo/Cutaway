package io.wetfloo.cutaway.data.model.auth

@JvmInline
value class AuthPreferences(
    val token: String? = null,
)
