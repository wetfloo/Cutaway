package io.wetfloo.cutaway.core.ui.compose.core

import androidx.compose.material3.Typography

val typography = Typography()
