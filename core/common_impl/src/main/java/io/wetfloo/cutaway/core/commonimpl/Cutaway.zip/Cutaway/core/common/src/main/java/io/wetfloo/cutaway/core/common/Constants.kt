package io.wetfloo.cutaway.core.common

// definitely important constants
const val SAMPLE_PROFILE_PICTURE_URL =
    "https://www.icegif.com/wp-content/uploads/rick-roll-icegif-5.gif"
const val RICKROLL_URL = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
